class Node:

    def __init__(self):
        self.attribute = None
        self.children = {}
        self.majority = None
     
